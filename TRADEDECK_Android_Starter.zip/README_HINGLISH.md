# TRADEDECK Android starter

Yeh starter source project hai, final/live app nahi. Abhi UI preview hai; login, cloud saving, invite validation, admin provisioning, CSV export aur complete P&L abhi connect/implement karne baaki hain.

## Phone se APK build
1. GitHub par private repository `TRADEDECK` banao.
2. ZIP ke andar ke saare files repository ke root mein upload karo.
3. Firebase Console mein Android app register karo. Package name: `com.tradedeck.app`.
4. Firebase se `google-services.json` download karke `app/google-services.json` mein add karo.
5. Firebase Authentication mein Email/Password enable karo; Firestore Database create karo.
6. Firestore Rules tab mein `firestore.rules` ka content publish karo.
7. GitHub repository → Actions → Build TRADEDECK APK → Run workflow.
8. Workflow complete ho to Artifacts se `TRADEDECK-debug-apk` download karo, ZIP extract karke APK install karo.

## Security
- Password, OTP, recovery code, GitHub token, private key ya service-account JSON kabhi chat mein share mat karna.
- Admin custom claim `admin=true` sirf trusted server-side process se set hona chahiye.
- Rules initial template hain; production se pehle testing/security review zaroori hai.
- Game-account passwords, OTPs, recovery codes ya login secrets collect/store nahi karne. Sirf lawful business records aur customer aliases use karo.
- Debug APK testing ke liye hai, public release ke liye signing, privacy policy aur full testing chahiye.
