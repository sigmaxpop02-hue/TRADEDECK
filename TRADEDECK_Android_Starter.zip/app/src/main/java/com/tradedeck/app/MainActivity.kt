package com.tradedeck.app
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val navy = Color(0xFF071426)
private val panel = Color(0xFF10243D)
private val cyan = Color(0xFF29C7F6)
private val muted = Color(0xFF9BB0C8)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  setContent { TradeDeckHome() }
 }
}
@Composable fun TradeDeckHome() {
 var tab by remember { mutableStateOf("Dashboard") }
 var add by remember { mutableStateOf(false) }
 MaterialTheme(colorScheme = darkColorScheme(primary=cyan, background=navy, surface=panel)) {
  Surface(Modifier.fillMaxSize(), color=navy) {
   Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
    Text("TRADEDECK", color=cyan, fontSize=28.sp, fontWeight=FontWeight.Black)
    Text("Business deal records • Private workspace", color=muted)
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
     listOf("Dashboard","Deals","Reports").forEach { FilterChip(selected=tab==it,onClick={tab=it},label={Text(it)}) }
    }
    when(tab) {
     "Dashboard" -> {
      Text("Overview", color=Color.White, fontSize=20.sp, fontWeight=FontWeight.Bold)
      Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
       MetricCard("Total deals","0",Modifier.weight(1f)); MetricCard("Open deals","0",Modifier.weight(1f))
      }
      Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
       MetricCard("Money in","₹0",Modifier.weight(1f)); MetricCard("Net P&L","₹0",Modifier.weight(1f))
      }
      Button(onClick={add=true}, modifier=Modifier.fillMaxWidth()) { Text("＋ Add a deal") }
      Text("No records yet. Add your first business record.", color=muted)
     }
     "Deals" -> Text("Deal records will appear here after secure Firebase integration.", color=muted)
     else -> { Text("Reports", color=Color.White, fontSize=20.sp); MetricCard("This month • Net P&L","₹0",Modifier.fillMaxWidth()) }
    }
    Text("Preview build: cloud login and saving are not connected yet.", color=muted, fontSize=11.sp)
   }
   if(add) AlertDialog(onDismissRequest={add=false},title={Text("New deal preview")},text={Text("The deal form is a visual preview and does not save records yet.")},confirmButton={TextButton(onClick={add=false}){Text("Close")}})
  }
 }
}
@Composable private fun MetricCard(label:String,value:String,modifier:Modifier=Modifier) {
 Card(modifier=modifier, colors=CardDefaults.cardColors(containerColor=panel), shape=RoundedCornerShape(16.dp)) {
  Column(Modifier.padding(14.dp)) { Text(label,color=muted,fontSize=12.sp); Text(value,color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold) }
 }
}
